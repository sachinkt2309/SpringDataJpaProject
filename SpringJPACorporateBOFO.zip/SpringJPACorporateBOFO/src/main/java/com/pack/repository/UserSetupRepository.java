package com.pack.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.pack.model.UserSetup;

public interface UserSetupRepository extends JpaRepository<UserSetup,String> {
	
	@Transactional
	@Modifying
	@Query(value="update user_setup1 set delete_status= :value  where  user_id = :userid",nativeQuery = true)
	public void deleteUser(String userid,int value);

	@Transactional
	@Modifying
	@Query(value="delete from user where user_name = :userid",nativeQuery = true)
	public void deleteLoginUser(String userid);
	
	
	public List<UserSetup> findByUserId(String userid);

	@Transactional
	@Modifying
	@Query(value="insert into user(user_name,password,roles,is_Active) values(:name,:pass,:role,:isActive)",nativeQuery = true)
	public void saveLoginUser(String name, String pass, String role, int isActive);
	

	@Transactional
	@Modifying
	@Query(value="update user_setup1 set department= :depart,address= :address,phone_number= :phone where user_id= :userid",nativeQuery = true)
	public void saveUpdate(String userid, String depart, String address, long phone);

	
	@Transactional
	@Modifying
	@Query(value="select * from user_setup1 where user_id = :username and new_user= :a",nativeQuery = true)
	public List<UserSetup> checkUser(String username,int a);

	
	@Transactional
	@Modifying
	@Query(value="update user_setup1 set user_password=:newpass where user_password = :curpass",nativeQuery = true)
	public void changePass(String curpass, String newpass);

	
	@Transactional
	@Modifying
	@Query(value="update user set password=:newpass where password = :curpass",nativeQuery = true)
	public void changeUserPass(String curpass, String newpass);



	
}
