package com.pack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pack.model.Corporate;
import com.pack.model.UserSetup;
import com.pack.service.UserSetupService;

@Controller
public class LoginController {
	@Autowired
    UserSetupService userService;
	
	@RequestMapping("/admin")
	public String admin()
	{
		return "index";
	}
	
	@RequestMapping(value="/user")
	public String usercurrentUserName(Model m) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username="";
		if (principal instanceof UserDetails) {
		username = username+((UserDetails)principal).getUsername();
		} else {
		username = username+principal.toString();
		}
        	System.out.println("name in login "+username);
        	m.addAttribute("userid",username);
        	// List<UserSetup> users=userService.checkNewUser(username);
//        	 if(userService.checkNewUser(username).isEmpty())
//        	 {
        		 return "FrontOfficeHomepage"; 
//        	 }
//        	 else 	
//        	 {
//        		 return "ChangePassword";
//        	 }
	}

//	@RequestMapping(value="/ChangePassValidation",method = RequestMethod.POST)
//	public String changePass(@RequestParam("userId") String userid,@RequestParam("curpassword") String curpass,@RequestParam("newpassword") String newpass,Model m) {
//		
//		userService.changeUserPass(curpass,newpass);
//		m.addAttribute("userid",userid);
//		return "FrontOfficeHomepage";
//		
//	}
}
