package com.pack.exception;

public class AccountNotFoundException  extends Exception{
	public String toString()
	{
		
		return "Account number  not found";
	} 
 

}
