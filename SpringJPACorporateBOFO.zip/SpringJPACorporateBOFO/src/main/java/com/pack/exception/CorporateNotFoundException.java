package com.pack.exception;

public class CorporateNotFoundException extends Exception{
	public String toString()
	{
		
		return "Corporate Id not found";
	} 

}
