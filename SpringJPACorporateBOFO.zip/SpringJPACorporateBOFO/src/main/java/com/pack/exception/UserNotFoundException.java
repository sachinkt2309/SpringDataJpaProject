package com.pack.exception;

public class UserNotFoundException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString()
	{
		
		return "User Id is not found";
	} 
 

}
